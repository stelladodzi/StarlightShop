# replit.md

## Overview

This is a modern e-commerce application built as a full-stack React application with Express.js backend. The project is designed as an Amazon-inspired global clothing retailer with a focus on seasonal collections, premium fashion accessories, and lifestyle products. The application features a sophisticated product catalog with seasonal categorization, shopping cart functionality, payment processing via Stripe, and a responsive design using shadcn/ui components.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for development tooling
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming and dark mode support
- **State Management**: React Context API for cart state, TanStack Query for server state
- **Routing**: Wouter for client-side routing
- **Forms**: React Hook Form with Zod validation resolvers

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Storage**: In-memory storage implementation with interface for future database integration
- **API Design**: RESTful APIs for products, cart operations, and order management
- **Session Management**: Express sessions with PostgreSQL session store configuration

### Database Design
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema**: Centralized schema definitions in shared directory
- **Tables**: Users, products, cart items, and orders with proper foreign key relationships
- **Migrations**: Drizzle Kit for database schema migrations

### Payment Integration
- **Provider**: Stripe for payment processing
- **Implementation**: Stripe Elements for secure payment forms
- **Security**: Server-side payment intent creation and confirmation

### Authentication & Authorization
- **Strategy**: Session-based authentication prepared for user management
- **Security**: CORS handling and secure session configuration
- **User Management**: User profiles with Stripe customer integration for payment processing

### Development Tools
- **Build System**: Vite for frontend bundling, esbuild for backend compilation
- **Type Safety**: Shared TypeScript interfaces between frontend and backend
- **Code Quality**: ESLint configuration and TypeScript strict mode
- **Hot Reload**: Vite HMR for frontend, tsx for backend development

### UI/UX Design Patterns
- **Design System**: Consistent spacing, typography, and color schemes using CSS custom properties
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Animations**: CSS transitions and custom animations for product interactions
- **Accessibility**: ARIA labels and semantic HTML throughout components

## External Dependencies

### Core Technologies
- **React Ecosystem**: React 18, React DOM, React Hook Form, TanStack Query
- **Backend Framework**: Express.js with TypeScript support
- **Database**: PostgreSQL with Drizzle ORM and Neon serverless driver
- **UI Framework**: Radix UI primitives with shadcn/ui component system

### Payment Processing
- **Stripe**: Complete payment infrastructure with React Stripe.js integration
- **Security**: PCI-compliant payment handling with Stripe Elements

### Development & Build Tools
- **Vite**: Modern build tool with React plugin and runtime error overlay
- **TypeScript**: Full-stack type safety with shared schema definitions
- **Tailwind CSS**: Utility-first CSS framework with PostCSS processing

### Third-Party Services
- **Session Storage**: connect-pg-simple for PostgreSQL session management
- **Image Hosting**: Unsplash for product imagery and hero banners
- **Fonts**: Google Fonts integration (Inter, Architects Daughter, DM Sans, Fira Code, Geist Mono)

### Utility Libraries
- **Date Handling**: date-fns for date manipulation and formatting
- **Class Management**: clsx and tailwind-merge for conditional styling
- **Icons**: Lucide React for consistent iconography
- **Validation**: Zod for runtime type validation and schema definition