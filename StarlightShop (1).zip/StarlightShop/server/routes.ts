import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import OpenAI from "openai";
import { storage } from "./storage";
import { insertProductSchema, insertCartItemSchema, insertOrderSchema } from "@shared/schema";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-08-27.basil",
});

// Initialize OpenAI if API key is available
let openai: OpenAI | null = null;
if (process.env.OPENAI_API_KEY) {
  openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Products API
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching products: " + error.message });
    }
  });

  app.get("/api/products/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const products = await storage.getProductsByCategory(category);
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching products: " + error.message });
    }
  });

  app.get("/api/products/season/:season", async (req, res) => {
    try {
      const { season } = req.params;
      const products = await storage.getProductsBySeason(season);
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching products: " + error.message });
    }
  });

  app.get("/api/products/featured", async (req, res) => {
    try {
      const products = await storage.getFeaturedProducts();
      res.json(products);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching featured products: " + error.message });
    }
  });

  // Cart API (for demo purposes, using session-based cart)
  app.get("/api/cart", async (req, res) => {
    try {
      // For demo, use a fixed user ID
      const userId = "demo-user";
      const cartItems = await storage.getCartItems(userId);
      res.json(cartItems);
    } catch (error: any) {
      res.status(500).json({ message: "Error fetching cart: " + error.message });
    }
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const validatedData = insertCartItemSchema.parse({
        ...req.body,
        userId: "demo-user", // For demo purposes
      });
      
      const cartItem = await storage.addToCart(validatedData);
      res.json(cartItem);
    } catch (error: any) {
      res.status(400).json({ message: "Error adding to cart: " + error.message });
    }
  });

  app.patch("/api/cart/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const { quantity } = req.body;
      
      const cartItem = await storage.updateCartItemQuantity(id, quantity);
      res.json(cartItem);
    } catch (error: any) {
      res.status(400).json({ message: "Error updating cart item: " + error.message });
    }
  });

  app.delete("/api/cart/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.removeFromCart(id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ message: "Error removing from cart: " + error.message });
    }
  });

  // Stripe payment route for one-time payments
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      const { amount } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // AI Chat Agent API
  app.post("/api/chat-agent", async (req, res) => {
    try {
      const { message, context } = req.body;
      
      if (!openai) {
        return res.json({ 
          response: "I'm here to help you find the perfect style! What are you looking for today?" 
        });
      }

      const systemPrompt = `You are a helpful fashion and style assistant for Starlight Inc, a premium e-commerce platform specializing in fashion, beauty, and lifestyle products. 

Your role is to:
- Help customers find products that match their style preferences
- Provide fashion advice and styling tips
- Answer questions about products, sizing, and trends
- Suggest complementary items and accessories
- Be friendly, knowledgeable, and enthusiastic about fashion

Our product categories include: Wigs, Lashes, Shoes, Digital Downloads, Kitchen, Bathroom, Food Delivery, Real Estate, Women's clothing, Men's clothing, Kids clothing, Accessories, and Beauty products.

Keep responses concise (1-3 sentences), helpful, and focused on fashion/shopping. Always maintain a warm, professional tone.`;

      // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      const completion = await openai.chat.completions.create({
        model: "gpt-5",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message }
        ],
        max_tokens: 150,
        temperature: 0.7,
      });

      const response = completion.choices[0].message.content || 
        "I'm here to help you find the perfect style! What are you looking for today?";

      res.json({ response });
    } catch (error: any) {
      console.error("AI Chat error:", error);
      res.json({ 
        response: "I'm here to help you find the perfect style! What are you looking for today?" 
      });
    }
  });

  // Stripe webhook (for production use)
  app.post("/api/stripe-webhook", async (req, res) => {
    try {
      // Handle Stripe webhook events here
      res.json({ received: true });
    } catch (error: any) {
      res.status(400).json({ message: "Webhook error: " + error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
