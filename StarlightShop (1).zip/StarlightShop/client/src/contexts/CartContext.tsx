import { createContext, useContext, useReducer, useEffect } from "react";
import { type CartItemWithProduct } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CartState {
  items: CartItemWithProduct[];
  isOpen: boolean;
  total: number;
  itemCount: number;
}

type CartAction = 
  | { type: "SET_ITEMS"; items: CartItemWithProduct[] }
  | { type: "ADD_ITEM"; item: CartItemWithProduct }
  | { type: "UPDATE_QUANTITY"; id: string; quantity: number }
  | { type: "REMOVE_ITEM"; id: string }
  | { type: "TOGGLE_CART" }
  | { type: "OPEN_CART" }
  | { type: "CLOSE_CART" }
  | { type: "CLEAR_CART" };

const cartReducer = (state: CartState, action: CartAction): CartState => {
  switch (action.type) {
    case "SET_ITEMS":
      const total = action.items.reduce((sum, item) => sum + (parseFloat(item.product.price) * item.quantity), 0);
      const itemCount = action.items.reduce((sum, item) => sum + item.quantity, 0);
      return { ...state, items: action.items, total, itemCount };
    
    case "ADD_ITEM":
      const newItems = [...state.items, action.item];
      const newTotal = newItems.reduce((sum, item) => sum + (parseFloat(item.product.price) * item.quantity), 0);
      const newItemCount = newItems.reduce((sum, item) => sum + item.quantity, 0);
      return { ...state, items: newItems, total: newTotal, itemCount: newItemCount };
    
    case "UPDATE_QUANTITY":
      const updatedItems = state.items.map(item => 
        item.id === action.id ? { ...item, quantity: action.quantity } : item
      );
      const updatedTotal = updatedItems.reduce((sum, item) => sum + (parseFloat(item.product.price) * item.quantity), 0);
      const updatedItemCount = updatedItems.reduce((sum, item) => sum + item.quantity, 0);
      return { ...state, items: updatedItems, total: updatedTotal, itemCount: updatedItemCount };
    
    case "REMOVE_ITEM":
      const filteredItems = state.items.filter(item => item.id !== action.id);
      const filteredTotal = filteredItems.reduce((sum, item) => sum + (parseFloat(item.product.price) * item.quantity), 0);
      const filteredItemCount = filteredItems.reduce((sum, item) => sum + item.quantity, 0);
      return { ...state, items: filteredItems, total: filteredTotal, itemCount: filteredItemCount };
    
    case "TOGGLE_CART":
      return { ...state, isOpen: !state.isOpen };
    
    case "OPEN_CART":
      return { ...state, isOpen: true };
    
    case "CLOSE_CART":
      return { ...state, isOpen: false };
    
    case "CLEAR_CART":
      return { ...state, items: [], total: 0, itemCount: 0 };
    
    default:
      return state;
  }
};

interface CartContextType {
  state: CartState;
  addToCart: (productId: string, quantity?: number) => Promise<void>;
  updateQuantity: (id: string, quantity: number) => Promise<void>;
  removeFromCart: (id: string) => Promise<void>;
  clearCart: () => Promise<void>;
  toggleCart: () => void;
  openCart: () => void;
  closeCart: () => void;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, {
    items: [],
    isOpen: false,
    total: 0,
    itemCount: 0,
  });
  
  const { toast } = useToast();

  // Load cart items on mount
  useEffect(() => {
    loadCartItems();
  }, []);

  const loadCartItems = async () => {
    try {
      const response = await apiRequest("GET", "/api/cart");
      const items = await response.json();
      dispatch({ type: "SET_ITEMS", items });
    } catch (error) {
      console.error("Failed to load cart items:", error);
    }
  };

  const addToCart = async (productId: string, quantity: number = 1) => {
    try {
      const response = await apiRequest("POST", "/api/cart", {
        productId,
        quantity,
      });
      
      await loadCartItems(); // Refresh cart
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      
      toast({
        title: "Added to Cart",
        description: "Item successfully added to your cart",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to add item to cart",
        variant: "destructive",
      });
    }
  };

  const updateQuantity = async (id: string, quantity: number) => {
    try {
      await apiRequest("PATCH", `/api/cart/${id}`, { quantity });
      dispatch({ type: "UPDATE_QUANTITY", id, quantity });
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update quantity",
        variant: "destructive",
      });
    }
  };

  const removeFromCart = async (id: string) => {
    try {
      await apiRequest("DELETE", `/api/cart/${id}`);
      dispatch({ type: "REMOVE_ITEM", id });
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      
      toast({
        title: "Removed from Cart",
        description: "Item removed from your cart",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove item",
        variant: "destructive",
      });
    }
  };

  const clearCart = async () => {
    try {
      // Clear all items for the demo user
      for (const item of state.items) {
        await apiRequest("DELETE", `/api/cart/${item.id}`);
      }
      dispatch({ type: "CLEAR_CART" });
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to clear cart",
        variant: "destructive",
      });
    }
  };

  const toggleCart = () => dispatch({ type: "TOGGLE_CART" });
  const openCart = () => dispatch({ type: "OPEN_CART" });
  const closeCart = () => dispatch({ type: "CLOSE_CART" });

  return (
    <CartContext.Provider value={{
      state,
      addToCart,
      updateQuantity,
      removeFromCart,
      clearCart,
      toggleCart,
      openCart,
      closeCart,
    }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
}
