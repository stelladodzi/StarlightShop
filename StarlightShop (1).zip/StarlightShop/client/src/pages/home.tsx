import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Header from "@/components/Header";
import SeasonalTabs from "@/components/SeasonalTabs";
import CategoryGrid from "@/components/CategoryGrid";
import LogisticsSection from "@/components/LogisticsSection";
import GlobalMap from "@/components/GlobalMap";
import CartSidebar from "@/components/CartSidebar";
import SocialMediaAgent from "@/components/SocialMediaAgent";
import Footer from "@/components/Footer";
import { useCart } from "@/contexts/CartContext";
import type { Product } from "@shared/schema";

const seasons = ["Summer", "Fall", "Winter", "Spring"];

export default function Home() {
  const { addToCart } = useCart();
  const [selectedSeason, setSelectedSeason] = useState<string | null>(null);
  
  const { data: featuredProducts = [] } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  const featured = featuredProducts.filter(p => p.featured).slice(0, 4);
  
  const seasonProducts = selectedSeason
    ? featuredProducts.filter((p) => p.season === selectedSeason)
    : [];

  const seasonBanners = {
    Summer: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=400",
    Fall: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=400",
    Winter: "https://images.unsplash.com/photo-1421749808763-0bd3d7c4ba48?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=400",
    Spring: "https://images.unsplash.com/photo-1490750967868-88aa4486c946?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=400",
  };

  const sliderSettings = {
    dots: true,
    infinite: true,
    speed: 800,
    slidesToShow: 2,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    responsive: [
      { breakpoint: 1024, settings: { slidesToShow: 2 } },
      { breakpoint: 640, settings: { slidesToShow: 1 } },
    ],
  };

  return (
    <div className="bg-background text-foreground">
      <Header />
      
      {/* Hero Banner */}
      <section className="relative">
        <img
          src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&h=500"
          alt="Fashion Banner"
          className="w-full h-[400px] object-cover"
        />
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black bg-opacity-50">
          <h1 className="text-5xl font-extrabold text-secondary">
            Welcome to Starlight Inc
          </h1>
          <p className="mt-4 text-lg text-muted-foreground">
            Fashion that shines in every season
          </p>
          <button className="mt-6 px-6 py-3 bg-gradient-to-r from-primary to-secondary text-primary-foreground rounded-xl shadow-lg hover:opacity-90">
            Shop Now
          </button>
        </div>
      </section>

      {/* Shop by Season with Carousel */}
      <section className="px-8 py-12 bg-muted/20">
        <h2 className="text-3xl font-bold text-secondary mb-6">
          Shop by Season
        </h2>
        <Slider {...sliderSettings}>
          {seasons.map((season) => (
            <div
              key={season}
              onClick={() => setSelectedSeason(season)}
              className="px-3 cursor-pointer group"
            >
              <div className="relative overflow-hidden rounded-xl shadow-xl transform hover:scale-105 transition duration-300">
                <img
                  src={seasonBanners[season as keyof typeof seasonBanners]}
                  alt={`${season} Banner`}
                  className="w-full h-48 object-cover group-hover:opacity-80"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 group-hover:bg-opacity-60 transition">
                  <h3 className="text-3xl font-extrabold text-white drop-shadow-lg">
                    {season}
                  </h3>
                </div>
              </div>
            </div>
          ))}
        </Slider>
      </section>

      {/* Animated Banner + Products */}
      {selectedSeason && (
        <section className="px-8 py-12 bg-background">
          {/* Season Banner */}
          <div className="mb-8 relative">
            <img
              src={seasonBanners[selectedSeason as keyof typeof seasonBanners]}
              alt={`${selectedSeason} banner`}
              className="w-full h-60 object-cover rounded-xl shadow-xl animate-pulse"
            />
            <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 rounded-xl">
              <h2 className="text-4xl font-extrabold text-secondary drop-shadow-lg">
                {selectedSeason} Collection
              </h2>
            </div>
          </div>

          {/* Products */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {seasonProducts.map((product) => (
              <div
                key={product.id}
                className="bg-card rounded-xl shadow-lg p-4 border border-border hover:border-primary/50 hover:scale-105 transition-all"
              >
                <img
                  src={product.imageUrl}
                  alt={product.name}
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                <h3 className="text-lg font-semibold text-foreground">
                  {product.name}
                </h3>
                <p className="text-muted-foreground">${product.price}</p>
                <button 
                  onClick={() => addToCart(product.id, 1)}
                  className="mt-3 w-full bg-gradient-to-r from-secondary to-primary text-secondary-foreground py-2 rounded-lg hover:opacity-90 transition-opacity"
                  data-testid={`button-add-to-cart-${product.id}`}
                >
                  Add to Cart
                </button>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Seasonal Tabs (Fancy Interactive Section) */}
      <SeasonalTabs />
      
      {/* Category Grid */}
      <CategoryGrid />
      
      {/* Logistics Section */}
      <LogisticsSection />
      
      {/* Global Map */}
      <GlobalMap />

      <CartSidebar />
      <SocialMediaAgent />
      <Footer />
    </div>
  );
}
