import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Facebook, Instagram, Twitter } from "lucide-react";
import { SiTiktok } from "react-icons/si";

export default function Footer() {
  const quickLinks = [
    "About Us",
    "Size Guide", 
    "Shipping Info",
    "Returns",
    "Contact",
  ];

  const categories = [
    "Wigs & Hair",
    "Lashes & Beauty",
    "Shoes & Footwear", 
    "Digital Downloads",
    "Home & Kitchen",
  ];

  return (
    <footer className="bg-card border-t border-border mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="text-2xl font-bold gradient-text mb-4" data-testid="text-footer-logo">
              Starlight Inc
            </div>
            <p className="text-muted-foreground mb-4" data-testid="text-footer-subtitle">
              lumere_splendit
            </p>
            <p className="text-sm text-muted-foreground" data-testid="text-footer-description">
              Premium fashion and lifestyle destination with global reach and local touch.
            </p>
            <div className="flex space-x-4 mt-6">
              <a href="https://facebook.com/starlightinc" target="_blank" rel="noopener noreferrer">
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary transition-colors" data-testid="button-facebook">
                  <Facebook className="h-5 w-5" />
                </Button>
              </a>
              <a href="https://instagram.com/starlightinc" target="_blank" rel="noopener noreferrer">
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary transition-colors" data-testid="button-instagram">
                  <Instagram className="h-5 w-5" />
                </Button>
              </a>
              <a href="https://tiktok.com/@starlightinc" target="_blank" rel="noopener noreferrer">
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary transition-colors" data-testid="button-tiktok">
                  <SiTiktok className="h-5 w-5" />
                </Button>
              </a>
              <a href="https://twitter.com/starlightinc" target="_blank" rel="noopener noreferrer">
                <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary transition-colors" data-testid="button-twitter">
                  <Twitter className="h-5 w-5" />
                </Button>
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4" data-testid="text-quick-links-title">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              {quickLinks.map((link) => (
                <li key={link}>
                  <Link href="#">
                    <Button 
                      variant="ghost" 
                      className="text-muted-foreground hover:text-foreground p-0 h-auto justify-start"
                      data-testid={`button-quick-link-${link.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {link}
                    </Button>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Categories */}
          <div>
            <h3 className="font-semibold mb-4" data-testid="text-categories-title">Categories</h3>
            <ul className="space-y-2 text-sm">
              {categories.map((category) => (
                <li key={category}>
                  <Link href="#">
                    <Button 
                      variant="ghost" 
                      className="text-muted-foreground hover:text-foreground p-0 h-auto justify-start"
                      data-testid={`button-footer-category-${category.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {category}
                    </Button>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="font-semibold mb-4" data-testid="text-newsletter-title">Stay Updated</h3>
            <p className="text-sm text-muted-foreground mb-4" data-testid="text-newsletter-description">
              Get the latest fashion trends and exclusive offers
            </p>
            <div className="space-y-3">
              <Input 
                type="email" 
                placeholder="Enter your email" 
                className="bg-input border border-border text-sm"
                data-testid="input-newsletter-email"
              />
              <Button 
                className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-medium text-sm"
                data-testid="button-newsletter-subscribe"
              >
                Subscribe
              </Button>
            </div>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        <div className="flex flex-col md:flex-row items-center justify-between text-sm text-muted-foreground">
          <p data-testid="text-copyright">
            &copy; 2024 Starlight Inc. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="#">
              <Button variant="ghost" className="text-muted-foreground hover:text-foreground p-0 h-auto" data-testid="button-privacy">
                Privacy Policy
              </Button>
            </Link>
            <Link href="#">
              <Button variant="ghost" className="text-muted-foreground hover:text-foreground p-0 h-auto" data-testid="button-terms">
                Terms of Service
              </Button>
            </Link>
            <Link href="#">
              <Button variant="ghost" className="text-muted-foreground hover:text-foreground p-0 h-auto" data-testid="button-cookies">
                Cookie Policy
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
