import { useState } from "react";
import { MessageCircle, X, Send, Bot } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";

interface Message {
  id: string;
  content: string;
  sender: "user" | "agent";
  timestamp: Date;
}

export default function SocialMediaAgent() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Hi! I'm here to help you find the perfect style. What are you looking for today?",
      sender: "agent",
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");

  const sendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    const currentMessage = inputMessage;
    setInputMessage("");

    try {
      // Call AI agent API
      const response = await apiRequest("POST", "/api/chat-agent", {
        message: currentMessage,
        context: "fashion_ecommerce"
      });
      
      const data = await response.json();
      
      const agentMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: data.response || "I'm here to help you find the perfect style! What are you looking for today?",
        sender: "agent",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, agentMessage]);
    } catch (error) {
      // Fallback response if AI fails
      const agentMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: "Thanks for your message! I'd be happy to help you find the perfect items. Let me connect you with our style experts who can provide personalized recommendations based on your preferences.",
        sender: "agent",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, agentMessage]);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      sendMessage();
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {isOpen && (
        <Card className="w-80 mb-4 bg-card border border-border shadow-lg" data-testid="card-chat-widget">
          <CardHeader className="bg-primary text-primary-foreground p-4 rounded-t-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center">
                  <Bot className="h-4 w-4 text-secondary-foreground" />
                </div>
                <div>
                  <h3 className="font-semibold" data-testid="text-agent-name">Style Assistant</h3>
                  <p className="text-xs opacity-90" data-testid="text-agent-status">Online now</p>
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="icon"
                className="text-primary-foreground/80 hover:text-primary-foreground h-8 w-8"
                onClick={() => setIsOpen(false)}
                data-testid="button-close-chat"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          </CardHeader>
          
          <CardContent className="p-4 h-64 overflow-y-auto space-y-3">
            {messages.map((message) => (
              <div 
                key={message.id} 
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                data-testid={`message-${message.id}`}
              >
                {message.sender === 'agent' && (
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mr-2">
                    <Bot className="h-3 w-3 text-primary-foreground" />
                  </div>
                )}
                <div className={`max-w-xs p-3 rounded-lg ${
                  message.sender === 'user' 
                    ? 'bg-primary text-primary-foreground ml-8' 
                    : 'bg-muted text-foreground'
                }`}>
                  <p className="text-sm" data-testid={`text-message-content-${message.id}`}>
                    {message.content}
                  </p>
                </div>
              </div>
            ))}
          </CardContent>
          
          <div className="p-4 border-t border-border">
            <div className="flex space-x-2">
              <Input 
                type="text" 
                placeholder="Ask about styles, sizes, or trends..." 
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                className="flex-1 text-sm"
                data-testid="input-chat-message"
              />
              <Button 
                size="icon"
                className="bg-primary hover:bg-primary/90" 
                onClick={sendMessage}
                data-testid="button-send-message"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </Card>
      )}
      
      {/* Chat Toggle Button */}
      <Button 
        className="bg-primary hover:bg-primary/90 text-primary-foreground w-14 h-14 rounded-full shadow-lg" 
        onClick={() => setIsOpen(!isOpen)}
        data-testid="button-toggle-chat"
      >
        <MessageCircle className="h-6 w-6" />
      </Button>
    </div>
  );
}
