export default function GlobalMap() {
  const continents = [
    { name: "North America", className: "continent-pulse", delay: "0s" },
    { name: "South America", className: "continent-pulse", delay: "0.5s" },
    { name: "Europe", className: "continent-pulse", delay: "1s" },
    { name: "Africa", className: "continent-pulse", delay: "1.5s" },
    { name: "Asia", className: "continent-pulse", delay: "2s" },
    { name: "Oceania", className: "continent-pulse", delay: "2.5s" },
  ];

  return (
    <section className="py-12 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4" data-testid="text-global-delivery-title">
            We Deliver To You
          </h2>
          <p className="text-muted-foreground" data-testid="text-global-delivery-subtitle">
            Fast, reliable delivery services across the globe
          </p>
        </div>
        
        {/* Simplified World Map */}
        <div className="relative max-w-4xl mx-auto">
          <svg 
            viewBox="0 0 800 400" 
            className="w-full h-auto"
            data-testid="svg-world-map"
          >
            {/* World Map Background */}
            <rect width="800" height="400" fill="var(--muted)" opacity="0.3" />
            
            {/* Simplified Continent Shapes with Pulsing Animation */}
            
            {/* North America */}
            <path 
              d="M80 80 L180 90 L160 180 L90 170 Z" 
              fill="var(--primary)" 
              opacity="0.7"
              className="continent-pulse"
              style={{ animationDelay: "0s" }}
              data-testid="continent-north-america"
            />
            
            {/* South America */}
            <path 
              d="M140 200 L180 190 L170 300 L130 290 Z" 
              fill="var(--secondary)" 
              opacity="0.7"
              className="continent-pulse"
              style={{ animationDelay: "0.5s" }}
              data-testid="continent-south-america"
            />
            
            {/* Europe */}
            <path 
              d="M280 60 L350 70 L340 120 L290 110 Z" 
              fill="var(--primary)" 
              opacity="0.7"
              className="continent-pulse"
              style={{ animationDelay: "1s" }}
              data-testid="continent-europe"
            />
            
            {/* Africa */}
            <path 
              d="M300 130 L380 140 L370 280 L310 270 Z" 
              fill="var(--secondary)" 
              opacity="0.7"
              className="continent-pulse"
              style={{ animationDelay: "1.5s" }}
              data-testid="continent-africa"
            />
            
            {/* Asia */}
            <path 
              d="M400 50 L550 60 L540 200 L410 190 Z" 
              fill="var(--primary)" 
              opacity="0.7"
              className="continent-pulse"
              style={{ animationDelay: "2s" }}
              data-testid="continent-asia"
            />
            
            {/* Oceania */}
            <path 
              d="M580 250 L650 260 L640 320 L590 310 Z" 
              fill="var(--secondary)" 
              opacity="0.7"
              className="continent-pulse"
              style={{ animationDelay: "2.5s" }}
              data-testid="continent-oceania"
            />
            
            {/* Labels */}
            <text x="130" y="130" fill="var(--foreground)" fontSize="14" textAnchor="middle" className="font-semibold">Americas</text>
            <text x="320" y="90" fill="var(--foreground)" fontSize="14" textAnchor="middle" className="font-semibold">Europe</text>
            <text x="340" y="200" fill="var(--foreground)" fontSize="14" textAnchor="middle" className="font-semibold">Africa</text>
            <text x="470" y="120" fill="var(--foreground)" fontSize="14" textAnchor="middle" className="font-semibold">Asia</text>
          </svg>
        </div>
        
        {/* Delivery Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
          <div className="text-center">
            <div className="text-2xl font-bold text-primary mb-1" data-testid="text-stat-countries">180+</div>
            <div className="text-sm text-muted-foreground">Countries</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-secondary mb-1" data-testid="text-stat-cities">500+</div>
            <div className="text-sm text-muted-foreground">Cities</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-primary mb-1" data-testid="text-stat-delivery">24H</div>
            <div className="text-sm text-muted-foreground">Express Delivery</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-secondary mb-1" data-testid="text-stat-satisfaction">99%</div>
            <div className="text-sm text-muted-foreground">Satisfaction</div>
          </div>
        </div>
      </div>
    </section>
  );
}
