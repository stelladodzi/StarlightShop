import { useState } from "react";
import { Link } from "wouter";
import { Search, User, Heart, ShoppingCart, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCart } from "@/contexts/CartContext";

export default function Header() {
  const { state, openCart } = useCart();
  const [searchQuery, setSearchQuery] = useState("");

  const categories = [
    { 
      name: "New Arrivals", 
      items: ["Latest Fashion", "Trending Now", "Designer Collection"] 
    },
    { 
      name: "Women", 
      items: ["Dresses", "Tops", "Bottoms", "Outerwear"] 
    },
    { 
      name: "Men", 
      items: ["Shirts", "Pants", "Jackets", "Suits"] 
    },
    { 
      name: "Kids", 
      items: ["Boys", "Girls", "Baby", "Toddler"] 
    },
    { 
      name: "Accessories", 
      items: ["Bags", "Jewelry", "Watches", "Sunglasses"] 
    },
  ];

  return (
    <header className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Bar */}
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center space-x-4 cursor-pointer" data-testid="link-logo">
              <div className="text-2xl font-bold gradient-text">
                Starlight Inc
              </div>
              <span className="text-sm text-muted-foreground hidden sm:block">lumere_splendit</span>
            </div>
          </Link>
          
          {/* Search Bar */}
          <div className="flex-1 max-w-lg mx-8 hidden md:block">
            <div className="relative">
              <Input 
                type="text" 
                placeholder="Search for clothing and accessories..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-2 bg-input border border-border rounded-lg focus:ring-2 focus:ring-ring focus:border-transparent pr-10"
                data-testid="input-search"
              />
              <Button 
                size="icon" 
                variant="ghost" 
                className="absolute right-2 top-1/2 -translate-y-1/2 h-8 w-8"
                data-testid="button-search"
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* User Actions */}
          <div className="flex items-center space-x-6">
            <Button variant="ghost" className="hidden sm:flex items-center space-x-1" data-testid="button-account">
              <User className="h-4 w-4" />
              <span>Account</span>
            </Button>
            <Button variant="ghost" className="hidden sm:flex items-center space-x-1" data-testid="button-wishlist">
              <Heart className="h-4 w-4" />
              <span>Wishlist</span>
            </Button>
            <Button 
              variant="ghost" 
              className="flex items-center space-x-1 relative" 
              onClick={openCart}
              data-testid="button-cart"
            >
              <ShoppingCart className="h-4 w-4" />
              <span>Cart</span>
              {state.itemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center" data-testid="text-cart-count">
                  {state.itemCount}
                </span>
              )}
            </Button>
          </div>
        </div>
        
        {/* Navigation Menu */}
        <nav className="border-t border-border">
          <div className="flex items-center space-x-8 h-12">
            {categories.map((category) => (
              <div key={category.name} className="nav-item relative">
                <Button 
                  variant="ghost" 
                  className="flex items-center space-x-1 text-foreground hover:text-primary font-medium h-auto p-2"
                  data-testid={`button-nav-${category.name.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <span>{category.name}</span>
                  <ChevronDown className="h-3 w-3" />
                </Button>
                <div className="nav-dropdown absolute top-full left-0 mt-2 w-64 bg-popover border border-border rounded-lg shadow-lg p-4 z-10">
                  <div className="space-y-2">
                    {category.items.map((item) => (
                      <Button
                        key={item}
                        variant="ghost"
                        className="block w-full text-left px-3 py-2 hover:bg-muted rounded text-sm justify-start"
                        data-testid={`button-subcategory-${item.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        {item}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            ))}
            <Link href="#">
              <Button variant="ghost" className="text-foreground hover:text-primary font-medium" data-testid="button-nav-digital">
                Digital Downloads
              </Button>
            </Link>
            <Link href="#">
              <Button variant="ghost" className="text-foreground hover:text-primary font-medium" data-testid="button-nav-home">
                Home & Living
              </Button>
            </Link>
          </div>
        </nav>
      </div>
    </header>
  );
}
