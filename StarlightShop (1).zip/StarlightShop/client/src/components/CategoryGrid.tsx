import { Card, CardContent } from "@/components/ui/card";

const categories = [
  {
    id: "wigs",
    name: "Wigs",
    subtitle: "Premium Hair",
    imageUrl: "https://images.unsplash.com/photo-1560066984-138dadb4c035?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
  },
  {
    id: "lashes",
    name: "Lashes",
    subtitle: "Beauty Essential",
    imageUrl: "https://images.unsplash.com/photo-1516975080664-ed2fc6a32937?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
  },
  {
    id: "shoes",
    name: "Shoes",
    subtitle: "Step in Style",
    imageUrl: "https://images.unsplash.com/photo-1549298916-b41d501d3772?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
  },
  {
    id: "digital",
    name: "Digital",
    subtitle: "Instant Access",
    imageUrl: "https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
  },
  {
    id: "kitchen",
    name: "Kitchen",
    subtitle: "Culinary Tools",
    imageUrl: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
  },
  {
    id: "bathroom",
    name: "Bathroom",
    subtitle: "Spa Experience",
    imageUrl: "https://images.unsplash.com/photo-1584622650111-993a426fbf0a?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
  },
  {
    id: "food",
    name: "Food Delivery",
    subtitle: "Fresh & Fast",
    imageUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
  },
  {
    id: "realestate",
    name: "Real Estate",
    subtitle: "Dream Homes",
    imageUrl: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
  },
];

export default function CategoryGrid() {
  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h2 className="text-3xl font-bold text-center mb-8" data-testid="text-category-title">
        Shop by Category
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {categories.map((category) => (
          <Card 
            key={category.id}
            className="category-card bg-card border border-border rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer group"
            data-testid={`card-category-${category.id}`}
          >
            <div className="relative overflow-hidden">
              <img 
                src={category.imageUrl} 
                alt={`${category.name} collection`}
                className="w-full h-32 object-cover group-hover:scale-110 transition-transform duration-300"
                data-testid={`img-category-${category.id}`}
              />
            </div>
            <CardContent className="p-4 text-center">
              <h3 className="font-semibold text-foreground" data-testid={`text-category-name-${category.id}`}>
                {category.name}
              </h3>
              <p className="text-sm text-muted-foreground mt-1" data-testid={`text-category-subtitle-${category.id}`}>
                {category.subtitle}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
