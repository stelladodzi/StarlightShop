import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import ProductCard from "@/components/ProductCard";
import { type Product } from "@shared/schema";

const seasons = [
  { id: "summer", name: "Summer", icon: "☀️" },
  { id: "fall", name: "Fall", icon: "🍂" },
  { id: "winter", name: "Winter", icon: "❄️" },
  { id: "spring", name: "Spring", icon: "🌸" },
];

export default function SeasonalTabs() {
  const [activeSeason, setActiveSeason] = useState("summer");

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/season", activeSeason],
  });

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Card className="bg-card border border-border">
        <CardContent className="p-6">
          <h2 className="text-3xl font-bold text-center mb-8" data-testid="text-seasonal-title">
            Shop by Season
          </h2>
          
          {/* Tab Navigation */}
          <div className="flex space-x-1 bg-muted p-1 rounded-lg mb-6">
            {seasons.map((season) => (
              <Button
                key={season.id}
                variant={activeSeason === season.id ? "default" : "ghost"}
                className={`flex-1 py-2 px-4 rounded-md font-medium transition-all ${
                  activeSeason === season.id
                    ? "bg-primary text-primary-foreground"
                    : "hover:bg-accent hover:text-accent-foreground"
                }`}
                onClick={() => setActiveSeason(season.id)}
                data-testid={`button-season-${season.id}`}
              >
                <span className="mr-2">{season.icon}</span>
                {season.name}
              </Button>
            ))}
          </div>
          
          {/* Content */}
          <div className="min-h-[400px]">
            {isLoading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" data-testid={`grid-season-${activeSeason}`}>
                {products.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </section>
  );
}
