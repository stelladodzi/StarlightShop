import { Truck, Clock, Shield, Globe } from "lucide-react";

export default function LogisticsSection() {
  const features = [
    {
      icon: <Truck className="h-8 w-8 text-primary" />,
      title: "Free Shipping",
      description: "On orders over $75",
    },
    {
      icon: <Clock className="h-8 w-8 text-secondary" />,
      title: "Express Delivery",
      description: "Same day in major cities",
    },
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: "Secure Packaging",
      description: "Premium protection guaranteed",
    },
    {
      icon: <Globe className="h-8 w-8 text-secondary" />,
      title: "Global Reach",
      description: "180+ countries served",
    },
  ];

  return (
    <section className="py-12 bg-gradient-to-r from-primary/10 to-secondary/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4" data-testid="text-logistics-title">
            Global Delivery. Local Speed.
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto" data-testid="text-logistics-subtitle">
            Experience world-class logistics with our premium shipping partners
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="text-center" data-testid={`feature-${index}`}>
              <div className="bg-primary/20 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                {feature.icon}
              </div>
              <h3 className="font-semibold mb-2" data-testid={`text-feature-title-${index}`}>
                {feature.title}
              </h3>
              <p className="text-muted-foreground text-sm" data-testid={`text-feature-description-${index}`}>
                {feature.description}
              </p>
            </div>
          ))}
        </div>
        
        {/* Logistics Visual */}
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          <div>
            <h3 className="text-2xl font-bold mb-4" data-testid="text-advanced-logistics">
              Powered by Advanced Logistics
            </h3>
            <div className="space-y-4">
              {[
                "Real-time tracking for all orders",
                "Temperature-controlled delivery for beauty products", 
                "White-glove service for premium items"
              ].map((feature, index) => (
                <div key={index} className="flex items-center space-x-3" data-testid={`logistics-feature-${index}`}>
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                    <svg className="w-4 h-4 text-primary-foreground" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span data-testid={`text-logistics-feature-${index}`}>{feature}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            {/* Animated Bulldozer representing strong logistics infrastructure */}
            <div className="bg-gradient-to-br from-primary/20 to-secondary/20 rounded-lg p-8 text-center">
              <div className="relative inline-block">
                <svg 
                  className="w-32 h-20 text-primary" 
                  viewBox="0 0 200 120" 
                  fill="currentColor"
                  data-testid="svg-bulldozer"
                >
                  {/* Bulldozer Body */}
                  <rect x="40" y="40" width="80" height="40" rx="5" />
                  {/* Cab */}
                  <rect x="90" y="20" width="40" height="40" rx="3" />
                  {/* Blade */}
                  <rect x="10" y="35" width="35" height="25" rx="2" />
                  {/* Animated Tracks */}
                  <g className="bulldozer-tracks">
                    <circle cx="50" cy="90" r="8" />
                    <circle cx="70" cy="90" r="8" />
                    <circle cx="90" cy="90" r="8" />
                    <circle cx="110" cy="90" r="8" />
                  </g>
                </svg>
              </div>
              <p className="text-muted-foreground mt-4" data-testid="text-bulldozer-caption">
                Reliable Infrastructure, Continuous Motion
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
