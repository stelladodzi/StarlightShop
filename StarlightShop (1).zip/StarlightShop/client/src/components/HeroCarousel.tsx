import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

const heroSlides = [
  {
    id: 1,
    title: "Summer Collection 2024",
    subtitle: "Discover the latest trends in fashion and lifestyle",
    buttonText: "Shop Now",
    imageUrl: "https://images.unsplash.com/photo-1469334031218-e382a71b716b?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800",
    gradient: "from-primary/30 to-secondary/30",
  },
  {
    id: 2,
    title: "Premium Accessories",
    subtitle: "Complete your look with our curated collection",
    buttonText: "Explore Collection",
    imageUrl: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800",
    gradient: "from-secondary/30 to-primary/30",
  },
  {
    id: 3,
    title: "Lifestyle & Home",
    subtitle: "Transform your space with our premium selections",
    buttonText: "Shop Home",
    imageUrl: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=800",
    gradient: "from-primary/40 to-secondary/20",
  },
];

export default function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length);
  };

  return (
    <section className="relative h-96 overflow-hidden">
      <div className="carousel-container relative w-full h-full">
        {heroSlides.map((slide, index) => (
          <div
            key={slide.id}
            className={`carousel-fade absolute inset-0 bg-cover bg-center ${
              index === currentSlide ? 'active' : ''
            }`}
            style={{
              backgroundImage: `linear-gradient(${slide.gradient}), url('${slide.imageUrl}')`,
            }}
            data-testid={`hero-slide-${slide.id}`}
          >
            <div className="flex items-center justify-center h-full">
              <div className="text-center text-white max-w-2xl px-4">
                <h1 className="text-4xl md:text-6xl font-bold mb-4" data-testid={`text-hero-title-${slide.id}`}>
                  {slide.title}
                </h1>
                <p className="text-xl mb-8" data-testid={`text-hero-subtitle-${slide.id}`}>
                  {slide.subtitle}
                </p>
                <Button 
                  className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 rounded-lg font-semibold transition-all transform hover:scale-105"
                  data-testid={`button-hero-cta-${slide.id}`}
                >
                  {slide.buttonText}
                </Button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Carousel Controls */}
      <Button
        variant="ghost"
        size="icon"
        className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full"
        onClick={prevSlide}
        data-testid="button-carousel-prev"
      >
        <ChevronLeft className="h-6 w-6" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full"
        onClick={nextSlide}
        data-testid="button-carousel-next"
      >
        <ChevronRight className="h-6 w-6" />
      </Button>
      
      {/* Carousel Indicators */}
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {heroSlides.map((_, index) => (
          <button
            key={index}
            className={`w-3 h-3 rounded-full transition-colors ${
              index === currentSlide ? 'bg-white' : 'bg-white/50'
            }`}
            onClick={() => setCurrentSlide(index)}
            data-testid={`button-carousel-indicator-${index}`}
          />
        ))}
      </div>
    </section>
  );
}
